import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import Canvas, Entry, Frame, Label, Text, Toplevel, Button, messagebox
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
import joblib

dataset = pd.read_csv('Penguins.csv')

imputer = SimpleImputer(strategy='mean')
dataset[['bill_length_mm', 'bill_depth_mm', 'flipper_length_mm']] = imputer.fit_transform(
    dataset[['bill_length_mm', 'bill_depth_mm', 'flipper_length_mm']])

# Extract features (x) and target (y)
x = dataset[['bill_length_mm', 'bill_depth_mm','flipper_length_mm']].values
y = dataset['species'].values

# Create a RandomForestClassifier and train it
classifier = RandomForestClassifier()
classifier.fit(x, y)

# Save the trained classifier
joblib.dump(classifier, "random-forest.joblib")

    
# Create the main application window
a = tk.Tk()
a.geometry("1920x1080")
a.title("PENGUIN SPECIES")
a.configure(bg="#F0F0FF")

# Creating the image background
frame = Frame(a, width=1920, height=1080)
frame.pack_propagate(False)
frame.pack()
img = ImageTk.PhotoImage(Image.open("BACK1.jpg"))  
label = Label(frame, image=img)
label.pack(fill='both', expand=True)

# Create a Label widget for the centered paragraph texta
paragraph_text = Label(a, text="Penguins are seabirds in the family Spheniscidae. They use their wings to swim underwater, but they cannot fly in the air. They eat fish and other seafood. Penguins lay their eggs and raise their babies on land.",
                       bg='#818996', font=("Garamond", 17))
paragraph_text.place(x=120, y=750)


# Create a function to scroll the text horizontally
scroll_speed = 3  # Adjust the scrolling speed by changing this value
direction = 1  # 1 for scrolling right, -1 for scrolling left

def scroll_text():
    global direction  
    x, y = int(paragraph_text.place_info().get('x')), int(paragraph_text.place_info().get('y'))
    
    if direction == 1:
        x -= scroll_speed
        if x + paragraph_text.winfo_width() <= 0:
            
            x = 1920
    else:
        x += scroll_speed
        if x >= 1920:
            
            x = -paragraph_text.winfo_width()
    
    paragraph_text.place(x=x, y=y)
    
    a.after(50, scroll_text)

scroll_text()  



# Create Canvas1
canvas1 = Canvas(a, width=300, height=200)
canvas1.place(x=100, y=0)

# Add Text with a transparent background
canvas1.create_rectangle(0, 0, 300, 300, fill='white', outline='')
canvas1.create_text(150, 100, text="PENGUIN SPECIES", font=("Arial", 24, "bold"))
canvas1.create_text(150, 130, text="(Predictor)", font=("Arial", 14))

# Create Canvas2
canvas2 = Canvas(a, width=310, height=1080)
canvas2.place(x=1250, y=0)

# Add Text with a transparent background
canvas2.create_rectangle(0, 0, 310, 1080, fill='white', outline='')
canvas2.create_text(140, 60, text="LOG IN TO YOUR ACCOUNT", font=("Helvetica", 12))

# Create text widget and specify size.
L1 = Label(a, bg="white", text="E-MAIL")
L1.place(x=1270, y=100)
L2 = Label(a, bg="white", text="PASSWORD")
L2.place(x=1270, y=140)
e1 = Entry(a, bd=3, fg="black", relief=tk.GROOVE, width=24)
e1.place(x=1360, y=100)
e2 = Entry(a, bd=3, fg="black", relief=tk.GROOVE, width=24)
e2.place(x=1360, y=140)

# Define LOGIN function
def LOGIN():
    x = e1.get()
    y = e2.get()
    if x == "" or y == "":
        messagebox.showinfo('Message', "Fill in the Username and Password")
    elif x == "ml@gmail.com" and y == "123":
        messagebox.showinfo('Message', "Inputs are correct")
        HOTELLOG()
    else:
        messagebox.showerror('Error', "Inputs are invalid")

    # Create a separator line after the LOGIN button
    separator = ttk.Separator(canvas2, orient="horizontal")
    separator.place(x=1270, y=180, relwidth=0.6)

# Define HOTELLOG function
def HOTELLOG():
    d = Toplevel()
    d.geometry("1600x800")
    d.title("Penguin_Species")
    d.configure(bg="#F0F0FF")

    # Creating the image background
    image = Image.open("Login.jpg")
    image = ImageTk.PhotoImage(image)  
    label = Label(d, image=image)
    label.image = image 
    label.place(x=0, y=0)
    

    image = Image.open("save.png")
    image = ImageTk.PhotoImage(image)  
    label = Label(d, image=image,width=500, height=500)
    label.image = image 
    label.place(x=975, y=150)


    L1 = Label(d, fg="white", bg="#4d888e", font=("Arial",14), text="BILL-LENGTH:")
    L1.place(x=1030, y=310)
    L2 = Label(d, fg="white", bg="#4d888e", font=("Arial",14), text="BILL-DEPTH:")
    L2.place(x=1030, y=360)
    L3 = Label(d, fg="white", bg="#4d888e", font=("Arial",14), text="FLIPPER-LENGTH:")
    L3.place(x=1030, y=410)
    e3 = Entry(d, bd=3, fg="black", relief=tk.FLAT, width=30)
    e3.place(x=1230, y=310)
    e4 = Entry(d, bd=3, fg="black", relief=tk.FLAT, width=30)
    e4.place(x=1230, y=360)
    e5 = Entry(d, bd=3, fg="black", relief=tk.FLAT, width=30)
    e5.place(x=1230, y=410)

    #Notes
    L4 = Label(d, fg="white", bg="#4d888e", font=("Arial",10), text="(Note: All dimensions are in mm)")
    L4.place(x=1130, y=620)

    # Create Canvas1
    canvas3 = Canvas(d, width=300, height=200)
    canvas3.place(x=100, y=0)

    # Add Text with a transparent background
    canvas3.create_rectangle(0, 0, 300, 300, fill='white', outline='')
    canvas3.create_text(150, 100, text="PENGUIN SPECIES", font=("Arial", 24, "bold"))
    canvas3.create_text(150, 130, text="(Predictor)", font=("Arial", 14))


    classifier=joblib.load("random-forest.joblib")

    def predict_species():
        bill_length_mm = float(e3.get())
        bill_depth_mm = float(e4.get())
        flipper_length_mm = float(e5.get())

        prediction = classifier.predict([[bill_length_mm, bill_depth_mm, flipper_length_mm]])
        prediction_result.config(text=f"Predicted Species: {prediction[0]}")
      

    i4 = Button(d, text="CLICK TO PREDICT",  bg="white", width=25, fg="black",command=predict_species)  
    i4.place(x=1230, y=470)
    

    prediction_result = tk.Label(d, fg="white", bg="#4d888e", text="", font=("Helvetica", 20))
    prediction_result.place(x=1050, y=540)

# Creating frames button for bottom
i5 = Label(a, text="© 2023 Penguin_Species.Inc", bg="white", fg="black")
i5.place(x=1320, y=740)
i9 = Label(a, text="Any Queries?", bg="white", fg="black")
i9.place(x=1350, y=650)
i12 = Label(a, text="Please Contact: +66 2 365 9110", bg="white", fg="black")
i12.place(x=1310, y=680)
i12 = Label(a, text="Email-us: penguin@prediction.com", bg="white", fg="black")
i12.place(x=1300, y=710)

# MAIN PAGE LOGIN BUTTON
i4 = Button(a, text="LOG IN", bg="white", width=12, fg="black", command=LOGIN) 
i4.place(x=1415, y=180)


# Start the tkinter main loop
a.mainloop()
